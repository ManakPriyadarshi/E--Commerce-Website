// ===============================
// SELECT ELEMENTS
// ===============================
const cartIcon = document.querySelector(".icons span:last-child");
const buttons = document.querySelectorAll(".card button");

// ===============================
// LOCAL STORAGE SETUP
// ===============================
let cart = JSON.parse(localStorage.getItem("cart")) || [];

// ===============================
// ADD TO CART FUNCTION
// ===============================
buttons.forEach((btn, index) => {
    btn.addEventListener("click", () => {

        const card = btn.closest(".card");

        const product = {
            id: index,
            name: card.querySelector("h3").innerText,
            price: card.querySelector(".price").innerText,
            image: card.querySelector("img").src,
            qty: 1
        };

        addToCart(product);
    });
});

// ===============================
// ADD ITEM LOGIC
// ===============================
function addToCart(product){

    let existing = cart.find(item => item.id === product.id);

    if(existing){
        existing.qty += 1;
    } else {
        cart.push(product);
    }

    updateStorage();
    updateCartUI();
    showToast("Added to Cart 🛒");
}

// ===============================
// UPDATE LOCAL STORAGE
// ===============================
function updateStorage(){
    localStorage.setItem("cart", JSON.stringify(cart));
}

// ===============================
// UPDATE CART COUNT (ICON)
// ===============================
function updateCartUI(){

    let total = cart.reduce((sum, item) => sum + item.qty, 0);

    cartIcon.innerText = `🛒 (${total})`;
}

// ===============================
// TOAST MESSAGE
// ===============================
function showToast(msg){

    let toast = document.createElement("div");
    toast.innerText = msg;

    toast.style.position = "fixed";
    toast.style.bottom = "20px";
    toast.style.right = "20px";
    toast.style.padding = "12px 20px";
    toast.style.background = "rgba(0,0,0,0.7)";
    toast.style.color = "#fff";
    toast.style.borderRadius = "10px";
    toast.style.backdropFilter = "blur(10px)";
    toast.style.zIndex = "999";

    document.body.appendChild(toast);

    setTimeout(()=>{
        toast.remove();
    },2000);
}

// ===============================
// LOAD CART ON PAGE LOAD
// ===============================
updateCartUI();

// ===============================
// OPTIONAL: CART CLICK ALERT
// ===============================
cartIcon.addEventListener("click", () => {
    alert("Cart feature coming next 😏");
});

function openKurta(){
    window.location.href = "kurta.html";
}

function goHome(){
    window.location.href = "index.html";
}


function openCargos(){
    window.location.href = "cargos.html";
}

//DATA LOAD SYSTEM


// =====================
// PRODUCT LOAD (DETAIL PAGE)
// =====================

let product = JSON.parse(localStorage.getItem("product"));

if(product){
    document.getElementById("name").innerText = product.name;
    document.getElementById("price").innerText = product.price;
    document.getElementById("productImage").src = product.image;
    document.getElementById("rating").innerText = product.rating;
}

// =====================
// CLICK FUNCTION (ADD IN ALL PAGES)
// =====================

function openProduct(id){

let products = {
    black_kurta:{
        name:"Black Kurta",
        price:"₹999",
        image:"images/black_kurta.jpg",
        rating:"⭐⭐⭐⭐☆"
    },
    kurta1:{
        name:"Olive Kurta",
        price:"₹899",
        image:"images/kurta1.jpg",   // FIXED
        rating:"⭐⭐⭐⭐⭐"
    },
    cargo5:{
        name:"Beige Cargo",
        price:"₹799",
        image:"images1/cargo5.jpg",   // FIXED
        rating:"⭐⭐⭐⭐☆"
    },
    cargo6:{
    name:"Complete Outfit Combo",
    price:"₹1499",
    image:"images/cargo6.jpg",
    rating:"⭐⭐⭐⭐⭐"
}
};

localStorage.setItem("product", JSON.stringify(products[id]));
window.location.href="product.html";
}


btn.addEventListener("click", (e)=>{
    e.stopPropagation();
    addToCart(product);
});

function openProduct(name, price, image, rating){

    let url = `product.html?name=${encodeURIComponent(name)}
    &price=${encodeURIComponent(price)}
    &image=${encodeURIComponent(image)}
    &rating=${encodeURIComponent(rating)}`;

    window.location.href = url;
}



function openProduct(id){

let products = {
    black_kurta:{
        name:"Black Kurta",
        price:"₹999",
        image:"images/black_kurta.jpg",
        rating:"⭐⭐⭐⭐☆"
    },

    kurta1:{
        name:"Olive Kurta",
        price:"₹899",
        image:"images/kurta1.jpg",
        rating:"⭐⭐⭐⭐⭐"
    },

    kurta_blue:{
        name:"Blue Kurta",
        price:"₹1099",
        image:"images/kurta_blue.jpg",
        rating:"⭐⭐⭐⭐☆"
    },

    orange_kurta:{
        name:"Orange Kurta",
        price:"₹999",
        image:"images/orange_kurta.jpg",
        rating:"⭐⭐⭐⭐⭐"
    }
};

localStorage.setItem("product", JSON.stringify(products[id]));
window.location.href="product.html";
}

// 🔹 Product Open
function openProduct(name, price, image){
  localStorage.setItem("pname", name);
  localStorage.setItem("pprice", price);
  localStorage.setItem("pimage", image);

  window.location.href = "product.html";
}

// 🔹 Load Product Data (product.html ke liye)
if(document.getElementById("name")){
  document.getElementById("name").innerText =
    localStorage.getItem("pname");

  document.getElementById("price").innerText =
    "₹" + localStorage.getItem("pprice");

  document.getElementById("image").src =
    localStorage.getItem("pimage");
}

// 🔹 Add to Cart
function addToCart(){
  let product = {
    name: localStorage.getItem("pname"),
    price: localStorage.getItem("pprice"),
    image: localStorage.getItem("pimage")
  };

  let cart = JSON.parse(localStorage.getItem("cart")) || [];
  cart.push(product);

  localStorage.setItem("cart", JSON.stringify(cart));

  alert("Added to Cart ❤️");
}

// 🔹 Open Cart Page
function openCart(){
  window.location.href = "cart.html";
}

// 🔹 Display Cart (cart.html ke liye)
if(document.getElementById("cartItems")){
  let cart = JSON.parse(localStorage.getItem("cart")) || [];

  function displayCart(){
    let container = document.getElementById("cartItems");
    container.innerHTML = "";

    cart.forEach((item, index) => {
      container.innerHTML += `
        <div class="cart-card">
          <img src="${item.image}" width="150">
          <h3>${item.name}</h3>
          <p>₹${item.price}</p>
          <button onclick="deleteItem(${index})">❌ Remove</button>
        </div>
      `;
    });
  }

  window.deleteItem = function(index){
    cart.splice(index,1);
    localStorage.setItem("cart", JSON.stringify(cart));
    displayCart();
  }

  displayCart();
}

function openCart(){
  window.location.href = "cart.html";
}

const images = [
    "images/kurta2product.jpg",
    "images/kurta1product.jpg",
    "images/kurta3product.jpg"
];

let index = 0;

function showImage() {
    document.getElementById("mainImage").src = images[index];
}

function nextImage() {
    index = (index + 1) % images.length;
    showImage();
}

function prevImage() {
    index = (index - 1 + images.length) % images.length;
    showImage();
}

function setImage(i) {
    index = i;
    showImage();
}

